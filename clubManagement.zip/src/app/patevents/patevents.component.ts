import { Component, OnInit } from '@angular/core';
import { ParticipantService } from '../participant.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { analyzeAndValidateNgModules } from '@angular/compiler';
//import { element } from 'protractor';

@Component({
  selector: 'app-patevents',
  templateUrl: './patevents.component.html',
  styleUrls: ['./patevents.component.css']
})
export class PateventsComponent implements OnInit {
  participant: any; 
  retrievedData:any;
  updateObj: any;
  events: any;
  ison: boolean;
  x: any;

  constructor(private router: Router,private toastr: ToastrService,private participantService: ParticipantService) {
    this.updateObj={name:'',collegeId:'',branch:'',phone:'',email:'',password:'',eventDetails: {}};
  }

  ngOnInit(): void {
    this.retrievedData = localStorage.getItem('participant');
    this.participant = JSON.parse(this.retrievedData);
    this.updateObj=this.participant;
    /*this.participantService.getParticipant(this.updateObj.email,this.updateObj.password).subscribe((data: any) => {
      localStorage.setItem('participant', JSON.stringify(data));
      this.retrievedData = localStorage.getItem('participant');
      this.participant = JSON.parse(this.retrievedData);
      this.updateObj=this.participant;
      console.log(this.myDate+"new date");
      this.updateObj.eventDetails.forEach(element1 => {
        console.log(element1.startDate);
        if(this.myDate > element1.startDate) {
          const i = this.updateObj.eventDetails.findIndex((element2) => {return element2.eventId === element1.eventId;});
          this.updateObj.eventDetails.splice(i, 1);
        }
      });
    });*/
    this.participantService.getParticipantEvents(this.updateObj.email,this.updateObj.password).subscribe((data: any) => {
      this.events=data;
    });
  }
  unRegister(event: any) {
    const i = this.updateObj.eventDetails.findIndex((element) => {return element.eventId === event.eventId;});
    this.updateObj.eventDetails.splice(i, 1);
    this.participantService.updateParticipant(this.updateObj).subscribe((data: any) => {
      if(data==1) {
         this.toastr.success('unregister' , 'unregister Success');
         const i = this.events.findIndex((element) => {return element.eventId === event.eventId;});
         this.events.splice(i, 1);
         localStorage.setItem('participant', JSON.stringify(this.participant));
      }
      else
         this.toastr.error('unregister' , 'unregister Failure');
    });
  }
  isOngoing(event: any) {
    let date: Date = new Date();
    if(new Date(event.startDate) <= date)
          return true;
    else
         return false;

  }
  participate(event: any) {
    console.log(event);
    localStorage.setItem('event', JSON.stringify(event));
    this.router.navigate(['description']);

  }

  showMore(event : any) {
    localStorage.setItem('event', JSON.stringify(event));
    this.router.navigate(['description']);
  }
  async isParticipate(event: any) {
    await this.participantService.isParticipate(event.eventId,this.participant.participantId).subscribe((data:any)=>{
      console.log(data.eventId+"ispat");
      if(data == 0) {
              return false;
      }
      else {
              return true;
      }
    });
  }


}
