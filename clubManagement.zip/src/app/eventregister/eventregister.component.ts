import { Component, OnInit } from '@angular/core';
import { MemberService } from '../member.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-eventregister',
  templateUrl: './eventregister.component.html',
  styleUrls: ['./eventregister.component.css']
})
export class EventregisterComponent implements OnInit {
  members: any;
  check: any;
  numbers = [{value: '0'}]; 
  email: [];
  i : any;

  event={eventName:'',startDate:'',endDate:'',description:'',eventType:'',mode:'',place:'',points:'',memberDetails:[]};
  constructor(private toastr: ToastrService,private memberService : MemberService,private router: Router ) { }

  ngOnInit(): void {
    this.i=0;
    this.memberService.getAllMembers().subscribe((data : any) => {this.members=data});
    //console.log(this.members);
  }
  async eventRegister() {
    await this.memberService.eventRegister(this.event,this.event.memberDetails).subscribe((result: any) => {
      console.log(this.event);
      this.check=result;
      if(this.check === 1)  {
        this.toastr.success('register' , 'Event Registration Success');
        if(this.event.eventType=="quiz" && this.event.mode=="online") {
          this.router.navigate(['quizconduct']);
        } else {
          this.router.navigate(['home2']);
        }
      }
      else {
        this.toastr.error('register' , 'Event Registration Failed');
        this.router.navigate(['eventreg']);
      }
    });
  }
  async apply() {
    await this.memberService.getMemberByEmail(this.numbers[this.i].value).subscribe((data : any)=>{
      this.event.memberDetails.push(data);
      console.log("pushed");
    });
  }

  addMember() {
    this.memberService.getMemberByEmail(this.numbers[this.i].value).subscribe((data : any)=>{
      delete data.eventDetails;
      this.event.memberDetails.push(data);
      console.log("pushed");
      this.i=this.i+1;
      this.numbers.push({value: '5'});
    });
  }

}
