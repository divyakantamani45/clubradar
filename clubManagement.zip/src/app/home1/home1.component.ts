import { Component, OnInit } from '@angular/core';
import { ParticipantService } from '../participant.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home1',
  templateUrl: './home1.component.html',
  styleUrls: ['./home1.component.css']
})
export class Home1Component implements OnInit {


  retrievedData:any;
  participant: any;
  events: any;
  constructor(private router: Router,private toastr: ToastrService ,private participantService: ParticipantService) { }

  ngOnInit(): void {
    this.retrievedData = localStorage.getItem('participant');
    this.participant = JSON.parse(this.retrievedData);
    console.log(this.participant.email + "from json");
    this.participantService.getAllEventsForPat(this.participant.participantId).subscribe((data: any) => {console.log(data) ; this.events = data; });
  }
  regEventForPat(event : any) {
    this.participant.eventDetails.push(event);
    console.log("modified");
    console.log(this.participant);

    this.participantService.updateParticipant(this.participant).subscribe((data: any) => {
      if(data==1) {
        const i = this.events.findIndex((element) => {return element.eventId === event.eventId;});
        this.events.splice(i, 1);
        localStorage.setItem('participant', JSON.stringify(this.participant));
        this.participantService.sendMail(this.participant.email,event).subscribe((data: any) => {console.log(data)});
        this.toastr.success('register' , 'Event Registration Success');
      } else {
        this.toastr.error('register' , 'Event Registration Failed');
      }
      console.log(data);
    });

    
  }

  showMore(event : any) {
    localStorage.setItem('event', JSON.stringify(event));
    this.router.navigate(['description']);
  }
  

}
