import { Component, OnInit } from '@angular/core';
import { ParticipantService } from '../participant.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { analyzeAndValidateNgModules } from '@angular/compiler';

@Component({
  selector: 'app-eventdescription',
  templateUrl: './eventdescription.component.html',
  styleUrls: ['./eventdescription.component.css']
})
export class EventdescriptionComponent implements OnInit {
  retrievedData:any;
  event: any;
  participant: any;
  check:any;
  x:any;
  imageUrl: string;
  fileToUpload: File = null;
  reader: FileReader;
  constructor(private router: Router,private toastr: ToastrService ,private participantService: ParticipantService) { }

  ngOnInit(): void {
    this.retrievedData = localStorage.getItem('event');
    this.event = JSON.parse(this.retrievedData);
    this.retrievedData = localStorage.getItem('participant');
    this.participant = JSON.parse(this.retrievedData);
    console.log(this.participant.eventDetails);
    this.x=this.isParticipate();
    console.log(this.x+"ison");
  }

  regEventForPat() {
    this.participant.eventDetails.push(this.event);
    console.log("modified");
    console.log(this.participant);

    this.participantService.updateParticipant(this.participant).subscribe((data: any) => {
      if(data==1) {
        //const i = this.events.findIndex((element) => {return element.eventId === event.eventId;});
        //this.events.splice(i, 1);
        localStorage.setItem('participant', JSON.stringify(this.participant));
        this.participantService.sendMail(this.participant.email,this.event).subscribe((data: any) => {console.log(data)});
        this.toastr.success('register' , 'Event Registration Success');
        localStorage.setItem('event', JSON.stringify(this.event));
        this.router.navigate(['description']);

      } else {
        this.toastr.error('register' , 'Event Registration Failed');
      }
      console.log(data);
    });   
  }

  isRegistered() {
    const i = this.participant.eventDetails.findIndex((element) => {return element.eventId === this.event.eventId;});
    if(i==-1)
      return false;
    else
      return true;
  }

  checkMode() {
    if(this.event.mode=="online")
        return true;
    return false;
  }

  isOngoing() {
    let date: Date = new Date();
    if(new Date(this.event.startDate) <= date)
          return true;
    else
         return false;
  }

  unRegister() {
    const i = this.participant.eventDetails.findIndex((element) => {return element.eventId === this.event.eventId;});
    this.participant.eventDetails.splice(i, 1);
    this.participantService.updateParticipant(this.participant).subscribe((data: any) => {
      if(data==1) {
         this.toastr.success('unregister' , 'unregister Success');
         //const i = this.events.findIndex((element) => {return element.eventId === event.eventId;});
         //this.events.splice(i, 1);
         localStorage.setItem('participant', JSON.stringify(this.participant));
         localStorage.setItem('event', JSON.stringify(this.event));
         this.router.navigate(['description']);
      }
      else
         this.toastr.error('unregister' , 'unregister Failure');
    });
  }

  checkType(): any {
    if(this.event.eventType=="quiz")
      return 1;
    else if(this.event.eventType=="online meeting") 
      return 2;
    else if(this.event.eventType=="file upload")
       return 3;
    else
      return 4;
  }
  goToPage() {
    this.router.navigate(['participate']);
  }
  async isParticipate() {
    await this.participantService.isParticipate(this.event.eventId,this.participant.participantId).subscribe((data:any)=>{
      console.log(data.eventId+"ispat");
      if(data == 0) {
              this.check = false;
      }
      else {
              this.check = true;
      }
    });
  }

  handleFileInput(file: FileList){
    this.fileToUpload = file.item(0);
    /*this.reader = new FileReader();
    this.reader.readAsDataURL(this.fileToUpload);
    this.reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
    };*/
  }
  SubmitAssignment() {
    this.participantService.postAssignment(this.participant.participantId,this.participant.name,this.event.eventId, this.fileToUpload).subscribe (
      (data: any) => {
        if(data==1) {
          console.log('done');
          this.imageUrl = '../../assets/images/power.jpg';
          this.toastr.success('submit' , 'submit Success');
          this.router.navigate(['patevents']);
          this.check=true;
        }
        else {
          this.toastr.error('submit' , 'submit Failed');
          this.router.navigate(['description']);
        }
      } 
    );
  }



}
