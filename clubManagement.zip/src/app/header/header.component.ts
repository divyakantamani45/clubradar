import { Component, OnInit } from '@angular/core';
import { ParticipantService } from '../participant.service';
import { MemberService } from '../member.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { inherits } from 'util';
import { JsonpClientBackend } from '@angular/common/http';

declare var jQuery: any;


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  participant: any; 
  retrievedData:any;
  variable: any;
  member: any;
  updateObj: any;
  updateObj2: any;
  imageUrl: string;
  fileToUpload: File = null;
  reader: FileReader;
  constructor(private toastr: ToastrService,private router: Router,private participantService: ParticipantService,private memberService: MemberService) {
    this.updateObj={name:'',collegeId:'',branch:'',phone:'',email:'',password:'',eventDetails: {}};
    this.updateObj2={name:'',collegeId:'',branch:'',phone:'',email:'',password:'',role:'',category:'',eventDetails: {}};

    this.imageUrl = '../../assets/images/default.jpg';
   }
  ngOnInit(): void {
    this.retrievedData = localStorage.getItem('participant');
    this.participant = JSON.parse(this.retrievedData);
    this.retrievedData = localStorage.getItem('member');
    this.member = JSON.parse(this.retrievedData);
  }
  getPatStatus(): any {
    this.retrievedData = localStorage.getItem('participant');
    this.participant = JSON.parse(this.retrievedData);
    return this.participantService.getUserLogged();
  }
  getMemStatus(): any {
    this.retrievedData = localStorage.getItem('member');
    this.member = JSON.parse(this.retrievedData);
    return this.memberService.getMemLogged();
  }
  logout(): any {
      this.participantService.setUserLoggedOut();
      this.memberService.setMemLoggedOut();
      this.router.navigate(['home']);
  }

  editParticipant() {
    
    this.retrievedData = localStorage.getItem('participant');
    this.participant = JSON.parse(this.retrievedData);
    this.updateObj=this.participant;
    console.log(this.updateObj);
    console.log(this.participant.eventDetails+"update events");
    this.imageUrl = "http://localhost:8080/RESTAPI_CLUB/image/"+ this.updateObj.imageName;
    jQuery('#editpopup').modal('show');
  }
  editMember() {
    
    this.retrievedData = localStorage.getItem('member');
    this.member = JSON.parse(this.retrievedData);
    this.updateObj2=this.member;
    console.log(this.updateObj2);
    console.log(this.member.eventDetails+"update events");
    this.imageUrl = "http://localhost:8080/RESTAPI_CLUB/image/"+ this.updateObj2.imageName;
    jQuery('#editmem').modal('show');
  }
 

  handleFileInput(file: FileList) {
    this.fileToUpload = file.item(0);
    this.reader = new FileReader();
    this.reader.readAsDataURL(this.fileToUpload);
    this.reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
    };
  }

  updateParticipant() {
    if(this.fileToUpload==null) {
      this.participantService.updateParticipant(this.updateObj).subscribe((data: any) => {
        if(data==1) {
          this.variable = JSON.stringify(this.updateObj);
          localStorage.setItem('participant', this.variable);
          this.toastr.success('Update' , 'Update Success');
        } else {
          this.toastr.error('Update' , 'Update Failed');
        }
      });
    }
    else {
      this.participantService.updatePatWithImg(this.updateObj,this.fileToUpload).subscribe((data: any) => {
        if(data==1) {
          this.updateObj.imageName=this.fileToUpload.name;
          this.variable = JSON.stringify(this.updateObj);
          localStorage.setItem('participant', this.variable);
          this.toastr.success('Update' , 'Update Success');
        } else {
          this.toastr.error('Update' , 'Update Failed');
        }
      });
    }
    jQuery('#editpopup').modal('hide');
  }






  updateMember() {
    if(this.fileToUpload==null) {
      this.memberService.updateMember(this.updateObj2).subscribe((data: any) => {
        if(data==1) {
          this.variable = JSON.stringify(this.updateObj2);
          localStorage.setItem('member', this.variable);
          this.toastr.success('Update' , 'Update Success');
        } else {
          this.toastr.error('Update' , 'Update Failed');
        }
      });
    }
    else {
      this.memberService.updateMemWithImg(this.updateObj2,this.fileToUpload).subscribe((data: any) => {
        if(data==1) {
          this.updateObj2.imageName=this.fileToUpload.name;
          this.variable = JSON.stringify(this.updateObj2);
          localStorage.setItem('member', this.variable);
          this.toastr.success('Update' , 'Update Success');
        } else {
          this.toastr.error('Update' , 'Update Failed');
        }
      });
    }
    jQuery('#editmem').modal('hide');
  }



  /*updateParticipant(){
    console.log(this.updateObj);
    this.participantService.postFile(this.updateObj, this.fileToUpload).subscribe (
      (data: any) => {
        if(data==null) {
          console.log('done');
          this.imageUrl = '../../assets/images/power.jpg';
          this.toastr.success('register' , 'Registration Success');
          this.router.navigate(['login']);
        }
        else {
          this.toastr.error('register' , 'Registration Failed');
          this.router.navigate(['register']);
        }
      } 
    );
  }*/

}
