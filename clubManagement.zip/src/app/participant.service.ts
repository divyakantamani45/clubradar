import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ParticipantService {

  isUserLogged: boolean;
  constructor(private httpClient: HttpClient) { 
    this.isUserLogged = false;
  }
  setUserLoggedIn(): any {
    this.isUserLogged=true;
  }
  setUserLoggedOut() {
    this.isUserLogged = false;
  }
  getUserLogged() {
    return this.isUserLogged;
  }
  getParticipant(email: any,password: any): any{
    return this.httpClient.get('RESTAPI_CLUB/webapi/myresource/getPatByUserPass/' + email +'/'+ password);
  }
  getAllEventsForPat(participantId : any): any {
    return this.httpClient.get('RESTAPI_CLUB/webapi/myresource/getAllEventsForPat/'+participantId);
  }

  updateParticipant(participant : any) {
    return this.httpClient.post('RESTAPI_CLUB/webapi/myresource/updateParticipant',participant);
  }

  getParticipantEvents(email: any,password: any): any{
    return this.httpClient.get('RESTAPI_CLUB/webapi/myresource/participantEvents/' + email +'/'+ password);
  }
  getAllQues(quizName: any): any{
    return this.httpClient.get('RESTAPI_CLUB/webapi/myresource/getAllQues/' + quizName);
  }

  sendMail(email: any,event: any):any{
    console.log(event.eventName);
    const formData: FormData = new FormData();
    formData.append('eventName', event.eventName);
    formData.append('startDate', event.startDate);
    formData.append('endDate', event.endDate);
    formData.append('email', email);
    return this.httpClient.post('RESTAPI_CLUB/webapi/myresource/mail' , formData);
  }
  sendResult(name: any,marks: any,c: any,email: any):any {
    const formData: FormData = new FormData();
    formData.append('eventName', name);
    formData.append('marks', marks);
    formData.append('total', c);
    formData.append('email', email);
    return this.httpClient.post('RESTAPI_CLUB/webapi/myresource/mailForResult' , formData);
  }







  updatePatWithImg(ImageForm: any, fileToUpload: File) {
    const formData: FormData = new FormData();
    formData.append('imageName', fileToUpload, fileToUpload.name);
    formData.append('participantId', ImageForm.participantId);
    formData.append('name', ImageForm.name);
    formData.append('collegeId', ImageForm.collegeId);
    formData.append('branch', ImageForm.branch);
    formData.append('phone', ImageForm.phone);
    formData.append('email', ImageForm.email);
    formData.append('password', ImageForm.password);
    formData.append('eventDetails', JSON.stringify(ImageForm.eventDetails));

    return this.httpClient.post('RESTAPI_CLUB/webapi/myresource/updatePatWithImg/',formData);
  }
  postFile(ImageForm: any, fileToUpload: File) {
    // const endpoint='RESTAPI/webapi/myresource/';
    const formData: FormData = new FormData();
    formData.append('imageName', fileToUpload, fileToUpload.name);
    formData.append('name', ImageForm.name);
    formData.append('collegeId', ImageForm.collegeId);
    formData.append('branch', ImageForm.branch);
    formData.append('phone', ImageForm.phone);
    formData.append('email', ImageForm.email);
    formData.append('password', ImageForm.password);

    return this.httpClient.post('RESTAPI_CLUB/webapi/myresource/regParticipant', formData);
  }


  storeCredits(eventId: any,participantId: any,marks: any) {
    const formData: FormData = new FormData();
    formData.append('eventId', eventId);
    formData.append('participantId', participantId);
    formData.append('marks', marks);
    return this.httpClient.post('RESTAPI_CLUB/webapi/myresource/storeCredits', formData); 
  }

  isParticipate(eventId:any,participantId:any) {
    return this.httpClient.get('RESTAPI_CLUB/webapi/myresource/isParticipate/' + eventId +'/'+ participantId);
  }

  postAssignment(participantId: any,name: any,eventId:any,fileToUpload: File) {
    const formData: FormData = new FormData();
    formData.append('imageName', fileToUpload, fileToUpload.name);
    formData.append('participantId', participantId);
    formData.append('name', name);
    formData.append('eventId', eventId);
    return this.httpClient.post('RESTAPI_CLUB/webapi/myresource/postAssignment', formData);
  }

  getEventIds(participantId: any) {
    return this.httpClient.get('RESTAPI_CLUB/webapi/myresource/getEventIds/' + participantId);
  }

}
