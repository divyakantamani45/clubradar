import { Component, OnInit } from '@angular/core';
import { ParticipantService } from '../participant.service';
import { MemberService } from '../member.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

declare var jQuery: any;

@Component({
  selector: 'app-profile2',
  templateUrl: './profile2.component.html',
  styleUrls: ['./profile2.component.css']
})
export class Profile2Component implements OnInit {

  participant: any; 
  retrievedData:any;
  variable: any;
  member: any;
  updateObj: any;
  imageUrl: string;
  fileToUpload: File = null;
  reader: FileReader;

  constructor(private toastr: ToastrService,private router: Router,private participantService: ParticipantService,private memberService: MemberService) { 
    this.updateObj={name:'',collegeId:'',branch:'',phone:'',email:'',password:'',role:'',category:'',eventDetails: {}};
    this.imageUrl = '../../assets/images/default.jpg';
  }

  ngOnInit(): void {
    this.retrievedData = localStorage.getItem('member');
    this.member = JSON.parse(this.retrievedData);
     this.updateObj=this.member;
  }
  editMember() {
    
    this.retrievedData = localStorage.getItem('member');
    this.member = JSON.parse(this.retrievedData);
    this.updateObj=this.member;
    console.log(this.updateObj);
    console.log(this.member.eventDetails+"update events");
    this.imageUrl = "http://localhost:8080/RESTAPI_CLUB/image/"+ this.updateObj.imageName;
    jQuery('#editmem').modal('show');
  }
 

  handleFileInput(file: FileList) {
    this.fileToUpload = file.item(0);
    this.reader = new FileReader();
    this.reader.readAsDataURL(this.fileToUpload);
    this.reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
    };
  }

  updateMember() {
    if(this.fileToUpload==null) {
      this.memberService.updateMember(this.updateObj).subscribe((data: any) => {
        if(data==1) {
          this.variable = JSON.stringify(this.updateObj);
          localStorage.setItem('member', this.variable);
          this.toastr.success('Update' , 'Update Success');
        } else {
          this.toastr.error('Update' , 'Update Failed');
        }
      });
    }
    else {
      this.memberService.updateMemWithImg(this.updateObj,this.fileToUpload).subscribe((data: any) => {
        if(data==1) {
          this.updateObj.imageName=this.fileToUpload.name;
          this.variable = JSON.stringify(this.updateObj);
          localStorage.setItem('member', this.variable);
          this.toastr.success('Update' , 'Update Success');
        } else {
          this.toastr.error('Update' , 'Update Failed');
        }
      });
    }
    jQuery('#editmem').modal('hide');
  }

}
