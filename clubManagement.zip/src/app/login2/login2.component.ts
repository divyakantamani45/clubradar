import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ParticipantService } from '../participant.service';
import { MemberService } from '../member.service';

import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login2',
  templateUrl: './login2.component.html',
  styleUrls: ['./login2.component.css']
})
export class Login2Component implements OnInit {

  constructor(private toastr: ToastrService,private router: Router, private memberService: MemberService,private participantService: ParticipantService) { }

  ngOnInit(): void {
  }
  async validateUser(loginForm: any) {
    console.log("Inside validate User");
    console.log(loginForm);
    await this.memberService.getMember(loginForm.email,loginForm.password).subscribe((data: any) => {
      if(data != null) {
        this.memberService.setMemLoggedIn();
        //console.log(data);
        localStorage.setItem('member', JSON.stringify(data));
        this.router.navigate(['home2']);
        this.toastr.success('Login' , 'Login Success');
      } else {
        this.toastr.error('Login' , 'Login Failure');
      } 
    },
    (error) => {
      this.toastr.error('Login' , 'Login Failure');
    });

  }

  getstatus(): any {
    return this.participantService.getUserLogged()||this.memberService.getMemLogged();
  }
}
