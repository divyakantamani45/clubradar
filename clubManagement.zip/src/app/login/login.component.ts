import { toBase64String } from '@angular/compiler/src/output/source_map';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ParticipantService } from '../participant.service';
import { MemberService } from '../member.service';

import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  constructor(private toastr: ToastrService,private router: Router, private participantService: ParticipantService,private memberService: MemberService) {}
  ngOnInit(): void {
  }
  async validateUser(loginForm: any) {
    console.log("Inside validate User");
    console.log(loginForm);
    await this.participantService.getParticipant(loginForm.email,loginForm.password).subscribe((data: any) => {
      if(data != null) {
        this.participantService.setUserLoggedIn();
        //console.log(data);
        localStorage.setItem('participant', JSON.stringify(data));

        this.router.navigate(['home1']);
        this.toastr.success('Login' , 'Login Success');
      } else {
        this.toastr.error('Login' , 'Login Failure');
      } 
    },
    (error) => {
      this.toastr.error('Login' , 'Login Failure');
    });

  }

  getstatus(): any {
    return this.participantService.getUserLogged()||this.memberService.getMemLogged();
  }
}


/*validateUser(loginForm: any): void {
    if (loginForm.email === 'admin' && loginForm.password === 'admin') {
      this.participantService.setUserLoggedIn();
      this.router.navigate(['home']);
    }
    else  {
        this.getParticipantDetails(loginForm.email , loginForm.password);
    }
    
  }
  getParticipantDetails(email: any , password: any) {
       this.participantService.getParticipant(email,password).subscribe((data: any) => {
         console.log(email+" "+password) ; 
         this.user = data; 
         if(this.user === null)  {
           alert("Invalid Credentials");
         }
         else {
           alert("successful Login");
           this.participantService.setUserLoggedIn();
           this.router.navigate(['home']);
         }
        });
  }*/