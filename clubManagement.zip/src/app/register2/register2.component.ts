import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ParticipantService } from '../participant.service';
import { MemberService } from '../member.service';

import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-register2',
  templateUrl: './register2.component.html',
  styleUrls: ['./register2.component.css']
})
export class Register2Component implements OnInit {

  imageUrl: string;
  fileToUpload: File = null;
  reader: FileReader;
  check: any;
  ngOnInit(): void {
  }
  constructor(private toastr: ToastrService,private router: Router , private memberService: MemberService,private paticipantService: ParticipantService) { 
    this.imageUrl = '../../assets/images/default.jpg';
  }
  /*registerUser(registerForm: any): void {
    console.log(registerForm);
    this.memberService.register(registerForm).subscribe((result: any) => {
      console.log(result);
      this.check=result;
      if(this.check === 1)  {
        this.toastr.success('register' , 'Registration Success');
        this.router.navigate(['login2']);
      }
      else {
        this.toastr.error('register' , 'Registration Failed');
        this.router.navigate(['register2']);
      }
      });
    console.log(registerForm);
  }*/
  
  handleFileInput(file: FileList){
    this.fileToUpload = file.item(0);
    this.reader = new FileReader();
    this.reader.readAsDataURL(this.fileToUpload);
    this.reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
    };
  }
  OnSubmit(imageForm: any) {
    console.log(imageForm);
    this.memberService.postFile(imageForm, this.fileToUpload).subscribe (
      (data: any) => {
        if(data==1) {
          console.log('done');
          this.imageUrl = '../../assets/images/power.jpg';
          this.toastr.success('register' , 'Registration Success');
          this.router.navigate(['login2']);
        }
        else {
          this.toastr.error('register' , 'Registration Failed');
          this.router.navigate(['register2']);
        }
      } 
    );
  }

  getstatus(): any {
    return this.memberService.getMemLogged()||this.paticipantService.getUserLogged();
  }

}
