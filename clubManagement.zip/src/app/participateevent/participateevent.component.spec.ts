import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ParticipateeventComponent } from './participateevent.component';

describe('ParticipateeventComponent', () => {
  let component: ParticipateeventComponent;
  let fixture: ComponentFixture<ParticipateeventComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ParticipateeventComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ParticipateeventComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
