import { Component, OnInit } from '@angular/core';
import { ParticipantService } from '../participant.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-participateevent',
  templateUrl: './participateevent.component.html',
  styleUrls: ['./participateevent.component.css']
})
export class ParticipateeventComponent implements OnInit {

  retrievedData:any;
  event: any;
  participant: any;
  quiz: any;
  name:any;
  answers = [];

  constructor(private router: Router,private toastr: ToastrService ,private participantService: ParticipantService) { }

  async ngOnInit(): Promise<void> {
    this.retrievedData = localStorage.getItem('event');
    this.event = JSON.parse(this.retrievedData);
    this.retrievedData = localStorage.getItem('participant');
    this.participant = JSON.parse(this.retrievedData);
    await this.participantService.getAllQues(this.event.eventName).subscribe((data : any) => {
      this.quiz=data;
      console.log(this.quiz);
      this.quiz.forEach(element => {
        this.answers.push({value:""});
      });
    });
    this.name=this.event.eventName;
  }
  async submitAns() {
    var c=0;
    var marks=0;
    this.quiz.forEach(element => {
      if(element.correctAns==this.answers[c].value) {
        marks=marks+1;
      }
      c=c+1;
    });
    await this.participantService.storeCredits(this.event.eventId,this.participant.participantId,marks).subscribe((data: any)=>{
      if(data==1) {
        this.participantService.sendResult(this.name,marks,c,this.participant.email).subscribe((data: any)=>{
          console.log(data);
        });
        this.router.navigate(['patevents']);
        this.toastr.success('submit' , 'submit Success');

      }
    })
    this.router.navigate(['patevents']);
  }

}
