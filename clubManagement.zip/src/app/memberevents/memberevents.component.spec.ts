import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MembereventsComponent } from './memberevents.component';

describe('MembereventsComponent', () => {
  let component: MembereventsComponent;
  let fixture: ComponentFixture<MembereventsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MembereventsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MembereventsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
