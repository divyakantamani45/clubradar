import { Component, OnInit } from '@angular/core';
import { ParticipantService } from '../participant.service';
import { MemberService } from '../member.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-memberevents',
  templateUrl: './memberevents.component.html',
  styleUrls: ['./memberevents.component.css']
})
export class MembereventsComponent implements OnInit {

  retrievedData: any;
  member : any;
  events: any;
  date : Date;
  eventDetails: any;
  constructor(private toastr: ToastrService,private router: Router,private participantService: ParticipantService,private memberService: MemberService) { }

   ngOnInit(): void {
    this.retrievedData = localStorage.getItem('member');
    this.member = JSON.parse(this.retrievedData);
    /*this.retrievedData = localStorage.getItem('member');
    this.member = JSON.parse(this.retrievedData);
    console.log(this.member+"in mem");
    console.log(this.member.eventDetails+"in mem");
    this.events=this.member.eventDetails;
    console.log(this.events);
    this.events.forEach((element) => {
      console.log(element.eventName+"in loop");
      this.date=new Date(element.endDate);
      this.date.setDate( this.date.getDate() + 10 );
      if(element.eventType!="quiz") {
        console.log(element.eventName);
        this.eventDetails.push(element);
      }
    });
    console.log(this.eventids);
    this.indexs.forEach(element => {
      this.events.splice(element.value,1);
    });*/
    this.memberService.getAllMemberEvents(this.member.email).subscribe((data: any)=> {
      this.eventDetails=data;
    });
  }
  goToPage(event: any) {
    localStorage.setItem('event', JSON.stringify(event));
    if(event.eventType== "file upload") {
      this.router.navigate(['uploads']);
    }

  }

}
