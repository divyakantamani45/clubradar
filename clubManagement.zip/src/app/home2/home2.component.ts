import { Component, OnInit } from '@angular/core';
import { ParticipantService } from '../participant.service';
import { MemberService } from '../member.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-home2',
  templateUrl: './home2.component.html',
  styleUrls: ['./home2.component.css']
})
export class Home2Component implements OnInit {
  participants: any; 
  retrievedData:any;
  member: any;
  constructor(private toastr: ToastrService ,private participantService: ParticipantService,private memberService: MemberService) {}

  ngOnInit(): void {
    this.retrievedData = localStorage.getItem('member');
    this.member = JSON.parse(this.retrievedData);
    console.log(this.member);
    this.memberService.getAllParticipants().subscribe( (result: any) => {console.log(result); this.participants = result; });
  }

}
