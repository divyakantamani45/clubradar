import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuizconductComponent } from './quizconduct.component';

describe('QuizconductComponent', () => {
  let component: QuizconductComponent;
  let fixture: ComponentFixture<QuizconductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuizconductComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuizconductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
