import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ParticipantService } from '../participant.service';
import { MemberService } from '../member.service';

import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-quizconduct',
  templateUrl: './quizconduct.component.html',
  styleUrls: ['./quizconduct.component.css']
})
export class QuizconductComponent implements OnInit {
  
  quiz = {quizName: '',questionDes:'',optiona_1:'',optionb_2:'',optionc_3:'',optiond_4:'',correctAns:''};
  constructor(private toastr: ToastrService,private router: Router, private participantService: ParticipantService,private memberService: MemberService) { }

  ngOnInit(): void {
  }
  validateForm() {
    this.memberService.registerQuiz(this.quiz).subscribe((data: any) => {
      if(data==1) {
         this.quiz.questionDes='';
         this.quiz.optiona_1='';
         this.quiz.optionb_2='';
         this.quiz.optionc_3='';
         this.quiz.optiond_4='';
         this.quiz.correctAns='';
         this.router.navigate(['quizconduct']);
      }
    });
  }
  end() {
    this.router.navigate(['home2']);
  }

}
