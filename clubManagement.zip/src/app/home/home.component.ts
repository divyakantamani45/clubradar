import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ParticipantService } from '../participant.service';
import { MemberService } from '../member.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  constructor(private router: Router,private participantService: ParticipantService,private memberService: MemberService) { }

  ngOnInit(): void {
  }
  login(): any {
    console.log("login clicked!!");
    this.router.navigate(['login']);
  }
  login2(): any {
    this.router.navigate(['login2']);
  }

  register(): any {
    this.router.navigate(['register']);
  }
  register2(): any {
    this.router.navigate(['register2']);
  }

  getstatus(): any {
    return this.participantService.getUserLogged()||this.memberService.getMemLogged();
  }
}
