import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ParticipantService } from '../participant.service';
import { MemberService } from '../member.service';

import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  imageUrl: string;
  fileToUpload: File = null;
  reader: FileReader;
  check: any;
  ngOnInit(): void {
  }
  constructor(private toastr: ToastrService,private router: Router , private participantService: ParticipantService, private memberService: MemberService) { 
    this.imageUrl = '../../assets/images/default.jpg';
  }
  /*registerUser(registerForm: any): void {
    console.log(registerForm);
    this.participantService.register(registerForm).subscribe((result: any) => {
      console.log(result);
      this.check=result;
      if(this.check === 1)  {
        this.toastr.success('register' , 'Registration Success');
        this.router.navigate(['login']);
      }
      else {
        this.toastr.error('register' , 'Registration Failed');
        this.router.navigate(['register']);
      }
      });
    console.log(registerForm);
  }*/
  
  handleFileInput(file: FileList){
    this.fileToUpload = file.item(0);
    this.reader = new FileReader();
    this.reader.readAsDataURL(this.fileToUpload);
    this.reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
    };
  }
  OnSubmit(imageForm: any) {
    console.log(imageForm);
    this.participantService.postFile(imageForm, this.fileToUpload).subscribe (
      (data: any) => {
        if(data==1) {
          console.log('done');
          this.imageUrl = '../../assets/images/power.jpg';
          this.toastr.success('register' , 'Registration Success');
          this.router.navigate(['login']);
        }
        else {
          this.toastr.error('register' , 'Registration Failed');
          this.router.navigate(['register']);
        }
      } 
    );
  }


  getstatus(): any {
    return this.participantService.getUserLogged()||this.memberService.getMemLogged();
  }
}
