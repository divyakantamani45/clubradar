import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MemberService {

  isMemLogged: boolean;
  constructor(private httpClient: HttpClient) { 
    this.isMemLogged = false;
  }
  setMemLoggedIn(): any {
    this.isMemLogged=true;
  }
  setMemLoggedOut() {
    this.isMemLogged = false;
  }
  getMemLogged() {
    return this.isMemLogged;
  }
  getMember(email: any,password: any): any{
    return this.httpClient.get('RESTAPI_CLUB/webapi/myresource/getMemByUserPass/' + email +'/'+ password);
  }
  updateMember(member : any) {
    return this.httpClient.post('RESTAPI_CLUB/webapi/myresource/updateMember',member);
  }
  getAllParticipants() {
    return this.httpClient.get('RESTAPI_CLUB/webapi/myresource/getAllParticipants');
  }

  eventRegister(eventForm : any,memberDetails : any) {
    //eventForm.memberDetails.push(memberDetails);
    console.log(JSON.stringify(eventForm.memberDetails)+"  in service ");
    return this.httpClient.post('RESTAPI_CLUB/webapi/myresource/regEvent',eventForm);
  }
  getMemberByEmail(email: any) {
    return this.httpClient.get('RESTAPI_CLUB/webapi/myresource/getMemByUserEmail/' + email);
  }

  getAllMembers() {
    return this.httpClient.get('RESTAPI_CLUB/webapi/myresource/getAllMembers');
  }

  registerQuiz(quizForm: any) {
    return this.httpClient.post('RESTAPI_CLUB/webapi/myresource/registerQuiz', quizForm);
  }

  postFile(ImageForm: any, fileToUpload: File) {
    // const endpoint='RESTAPI/webapi/myresource/';
    const formData: FormData = new FormData();
    formData.append('imageName', fileToUpload, fileToUpload.name);
    formData.append('name', ImageForm.name);
    formData.append('collegeId', ImageForm.collegeId);
    formData.append('branch', ImageForm.branch);
    formData.append('phone', ImageForm.phone);
    formData.append('email', ImageForm.email);
    formData.append('password', ImageForm.password);
    formData.append('role', ImageForm.role);
    formData.append('category', ImageForm.category);

    return this.httpClient.post('RESTAPI_CLUB/webapi/myresource/regMember', formData);
  }

  updateMemWithImg(ImageForm: any, fileToUpload: File) {
    // const endpoint='RESTAPI/webapi/myresource/';
    const formData: FormData = new FormData();
    formData.append('imageName', fileToUpload, fileToUpload.name);
    formData.append('memberId', ImageForm.memberId);
    formData.append('name', ImageForm.name);
    formData.append('collegeId', ImageForm.collegeId);
    formData.append('branch', ImageForm.branch);
    formData.append('phone', ImageForm.phone);
    formData.append('email', ImageForm.email);
    formData.append('password', ImageForm.password);
    formData.append('role', ImageForm.role);
    formData.append('category', ImageForm.category);
    formData.append('eventDetails', JSON.stringify(ImageForm.eventDetails));
    return this.httpClient.post('RESTAPI_CLUB/webapi/myresource/updateMemWithImg', formData);
  }
  getAllMemberEvents(email: any) {
    return this.httpClient.get('RESTAPI_CLUB/webapi/myresource/getAllMemberEvents/' + email);
  }

  getAllUploads(eventId: any) {
    return this.httpClient.get('RESTAPI_CLUB/webapi/myresource/getAllUploads/' + eventId);
  }
  giveScore(upload: any,credit: any) {
    const formData: FormData = new FormData();
    formData.append('uploadId', upload.uploadId);
    formData.append('eventId', upload.eventId);
    formData.append('participantId', upload.participantId);
    formData.append('name', upload.name);
    formData.append('imageName', upload.imageName);
    formData.append('credit', credit);
    return this.httpClient.post('RESTAPI_CLUB/webapi/myresource/giveScore', formData);

  }

}
