import { Component, OnInit } from '@angular/core';
import { ParticipantService } from '../participant.service';
import { MemberService } from '../member.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.css']
})
export class HistoryComponent implements OnInit {

  retrievedData: any;
  participant: any;
  credits:any;
  eventDetails: any;

  constructor(private toastr: ToastrService,private router: Router,private participantService: ParticipantService,private memberService: MemberService) { }

  ngOnInit(): void {
    this.retrievedData = localStorage.getItem('participant');
    this.participant = JSON.parse(this.retrievedData); 
    this.participantService.getEventIds(this.participant.participantId).subscribe((data: any) => {
      console.log(data);
      this.eventDetails=data; 
    });
  }
  showMore(event : any) {
    localStorage.setItem('event', JSON.stringify(event));
    this.router.navigate(['description']);
  }

}
