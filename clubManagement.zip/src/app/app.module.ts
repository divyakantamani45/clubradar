import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule }   from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { AuthGuard } from './auth.guard';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
//import { NotificationComponent } from './notification/notification.component'; 

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { HeaderComponent } from './header/header.component';
import { Home1Component } from './home1/home1.component';
import { Home2Component } from './home2/home2.component';
import { Login2Component } from './login2/login2.component';
import { Register2Component } from './register2/register2.component';
import { EventregisterComponent } from './eventregister/eventregister.component';
import { PateventsComponent } from './patevents/patevents.component';
import { EventdescriptionComponent } from './eventdescription/eventdescription.component';
import { QuizconductComponent } from './quizconduct/quizconduct.component';
import { ParticipateeventComponent } from './participateevent/participateevent.component';
import { ProfileComponent } from './profile/profile.component';
import { MembereventsComponent } from './memberevents/memberevents.component';
import { UploadsComponent } from './uploads/uploads.component';
import { Profile2Component } from './profile2/profile2.component';
import { HistoryComponent } from './history/history.component';

const appRoot: Routes = [{path: '' , component: HomeComponent},
                         {path: 'home' , component: HomeComponent},
                         {path: 'login' , component: LoginComponent},
                         {path: 'register', component: RegisterComponent},
                         {path: 'login2' , component: Login2Component},
                         {path: 'register2', component: Register2Component},
                         {path: 'home1',canActivate: [AuthGuard], component: Home1Component},
                         {path: 'home2', canActivate: [AuthGuard],component: Home2Component},
                         {path: 'eventreg',canActivate: [AuthGuard], component: EventregisterComponent},
                         {path: 'patevents',canActivate: [AuthGuard], component: PateventsComponent},
                         {path: 'description',canActivate: [AuthGuard], component: EventdescriptionComponent},
                         {path: 'quizconduct',canActivate: [AuthGuard], component: QuizconductComponent},
                         {path: 'participate', canActivate: [AuthGuard],component: ParticipateeventComponent},
                         {path: 'profile', canActivate: [AuthGuard],component: ProfileComponent},
                         {path: 'memberevents', canActivate: [AuthGuard],component: MembereventsComponent},
                         {path: 'uploads', canActivate: [AuthGuard],component: UploadsComponent},
                         {path: 'profile2', canActivate: [AuthGuard],component: Profile2Component},
                         {path: 'history', canActivate: [AuthGuard],component: HistoryComponent}];


@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    Register2Component,
    LoginComponent,
    Login2Component,
    HomeComponent,
    HeaderComponent,
    Home1Component,
    Home2Component,
    EventregisterComponent,
    PateventsComponent,
    EventdescriptionComponent,
    QuizconductComponent,
    ParticipateeventComponent,
    ProfileComponent,
    MembereventsComponent,
    UploadsComponent,
    Profile2Component,
    HistoryComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    RouterModule.forRoot(appRoot),
    HttpClientModule,
    ToastrModule.forRoot(),
    BrowserAnimationsModule
  ],
  providers: [AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
