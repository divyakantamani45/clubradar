import { Component, OnInit } from '@angular/core';
import { ParticipantService } from '../participant.service';
import { MemberService } from '../member.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-uploads',
  templateUrl: './uploads.component.html',
  styleUrls: ['./uploads.component.css']
})
export class UploadsComponent implements OnInit {

  retrievedData: any;
  event: any;
  fileUploads: any;
  credit: any;

  constructor(private toastr: ToastrService,private router: Router,private participantService: ParticipantService,private memberService: MemberService) { }

  ngOnInit(): void {
    this.retrievedData = localStorage.getItem('event');
    this.event = JSON.parse(this.retrievedData);
    this.memberService.getAllUploads(this.event.eventId).subscribe((data: any)=> {
      this.fileUploads=data;
    })
  }

  goToPage(upload: any) {
    //alert(upload.name);
    console.log(this.credit);
    
    this.memberService.giveScore(upload,this.credit).subscribe((data: any) => {
      console.log(data);
      if(data==1) {
        const i = this.fileUploads.findIndex((element) => {return element === upload});
        this.fileUploads.splice(i, 1);
      }
    })
  }

}
